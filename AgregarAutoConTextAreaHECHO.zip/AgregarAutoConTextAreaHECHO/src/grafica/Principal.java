//5-11-24
package grafica;
public class Principal{

	public static void main(String[] args) {
		FrmAgregarAuto vent=new FrmAgregarAuto();
		vent.setVisible(true);
		
	}
}