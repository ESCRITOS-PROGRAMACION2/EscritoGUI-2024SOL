package grafica;

public class Main {

	public static void main(String[] args) {
		FrmAgregarAuto vent=new FrmAgregarAuto();
		vent.setVisible(true);

	}

}
